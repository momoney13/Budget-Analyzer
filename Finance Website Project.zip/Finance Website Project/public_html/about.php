<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About</title>
    <link rel="stylesheet" href="Style.css">
</head>
<body>
<h1>Personal Budget Analyzer</h1>
<h3>Track Your Spending. Build Better Habits.</h3>

<img src="https://cdn.iconscout.com/icon/free/png-512/free-market-icon-svg-download-png-453340.png?f=webp&w=512" class="top-right-corner"> <!-- adds image -->
<!-- puts the image in the top right corner -->
<style>
    .top-right-corner {
        position: absolute;
        top: 0;
        right: 0;
        z-index: 9999; /* Ensures it stays on top of other content */
        width: 100px;  /* Adjust size */
        height: auto;
    }
</style>
<nav> <!--Start of navigation method-->
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="income&expenses.php">Monthly Spending Analyzer</a></li>
        <li><a href="debt.php">Debt Payoff Planner</a></li>
        <li><a href="about.php">About</a></li>
    </ul>
</nav>

<!-- ORIGINAL CODE: About page content -->
<!-- AI-ASSISTED: Added CSS class for styling -->
<main class="about-container">
    <h2>About The Personal Budget Analyzer</h2>
    <p>The Personal Budget Analyzer is a web application designed to help people understand their day-to-day finances and make informed financial decisions. Instead of showing a single calculation, it brings together income, expenses, and debt repayment information so users can better understand their financial situation.</p>

    <h2>What The Application Does</h2>
    <p>Users enter income and expenses through forms and organize spending into categories. The application analyzes the information to show totals, compare income with expenses, and summarize spending by category. The Monthly Spending Dashboard provides a visual representation of spending, while the Monthly Spending Analyzer helps users understand how their expenses compare to their income. The Debt Payoff Planner allows users to explore debt repayment calculations and better understand their repayment options.</p>

    <h2>How It Was Developed</h2>
    <p>The application uses HTML to structure its pages and forms, CSS to provide a consistent and readable interface, PHP to process submitted information and perform the budget calculations, and a json flatfile to store the information between visits. The file is the application's external data source: PHP will read and update records there as users add or change their financial information. Keeping the data in a flatfile allows the application to build summaries from multiple entries rather than relying on a one-time form submission.</p>
    <p>Development was organized around the main tasks a user needs to complete: reviewing a monthly spending dashboard, analyzing income and expenses, and planning debt repayment. The navigation connects these areas, while the shared colors, headings, and layout help the pages feel like one application. Form values are checked before they are stored, and calculations use the saved records so that the displayed summaries stay connected to the user's entries.</p>

    <h2>Team Contribution</h2>
    <p>The Personal Budget Analyzer was developed by Maria Torres Alaniz, Dominic Mistretta, and Ben Momeni. Each group member contributed to different aspects of the application.</p>
    <p>Maria focused on the HTML and CSS development of the website. The group wanted to ensure that users could easily navigate the application and understand the financial information presented to them. This included developing the overall layout, navigation, and styling across the application. Some artificial intelligence assistance was used during the development, particularly to help create the donut chart displayed on the home dashboard. <b>All use of AI is noted within the application's code.</b></p>
    <p>Dominic worked on the PHP forms and calculations that support the application's financial analysis features. These features allow users to enter financial information and receive feedback to help them better understand their spending and debt repayment. </p>
    <p>Ben worked on the external data source portion of the assignment. His work focused on implementing the data storage functionality needed to support the application.</p>
</main>


</body>
</html>